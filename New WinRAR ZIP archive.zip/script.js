document.getElementById("application-form").addEventListener("submit", function(e) {
  e.preventDefault();
  const element = document.getElementById("application-form");
  html2pdf().from(element).save("erize.pdf");
});
// İstifadəçini qeydiyyatdan keçirt
document.getElementById("register-submit").addEventListener("click", function () {
  const name = document.getElementById("register-name").value.trim();
  const email = document.getElementById("register-email").value.trim();
  const fin = document.getElementById("register-fin").value.trim();
  const password = document.getElementById("register-password").value;

  if (!name || !email || !fin || !password) {
    alert("Bütün sahələri doldurun!");
    return;
  }

  let users = JSON.parse(localStorage.getItem("users")) || [];

  // Eyni email ilə qeydiyyat olubmu?
  const existingUser = users.find((user) => user.email === email);
  if (existingUser) {
    alert("Bu email ilə artıq qeydiyyat var. Zəhmət olmasa daxil olun.");
    return;
  }

  // Yeni istifadəçini əlavə et
  users.push({ name, email, fin, password });
  localStorage.setItem("users", JSON.stringify(users));
  alert("Uğurla qeydiyyatdan keçdiniz!");

  // Avtomatik olaraq daxil ol
  localStorage.setItem("loggedInUser", JSON.stringify({ email, name }));
  window.location.href = "dashboard.html"; // Əsas səhifəyə yönləndir
});
document.querySelector(".pulse").addEventListener("click", function () {
  const email = document.querySelector('input[type="email"]').value.trim();
  const password = document.querySelector('input[type="password"]').value;

  let users = JSON.parse(localStorage.getItem("users")) || [];
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    localStorage.setItem("loggedInUser", JSON.stringify({ email: user.email, name: user.name }));
    alert("Uğurla daxil oldunuz!");
    window.location.href = "dashboard.html";
  } else {
    alert("Email və ya şifrə yanlışdır!");
  }
});
